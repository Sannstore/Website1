.sc-axis {background-image: url('<?=assets('images/cards/axis.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-byu {background-image: url('<?=assets('images/cards/byu.svg')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-indosat {background-image: url('<?=assets('images/cards/indosat.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-smartfren {background-image: url('<?=assets('images/cards/smartfren.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-telkomsel {background-image: url('<?=assets('images/cards/telkomsel.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-three {background-image: url('<?=assets('images/cards/three.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.sc-axiata {background-image: url('<?=assets('images/cards/xl-axiata.png')?>');background-color: white;background-repeat: no-repeat;background-size: auto 26px;background-position: 98% 50%;}
.copy {cursor: pointer;}
