        <script src="<?= assets("js/jquery.js"); ?>"></script>
        <script src="<?= assets("js/jquery.min.js"); ?>"></script>
        <script src="<?= assets("js/popper.min.js"); ?>"></script>
        <script src="<?= assets("js/bootstrap.min.js"); ?>"></script>
        <script src="<?= assets("js/waves.js"); ?>"></script>
        <script src="<?= assets("js/jquery.slimscroll.js"); ?>"></script>

        <script src="<?= assets("waypoints/lib/jquery.waypoints.min.js"); ?>"></script>
        <script src="<?= assets("counterup/jquery.counterup.min.js"); ?>"></script>

        <script src="<?= assets("chart.js/chart.bundle.js"); ?>"></script>
        <script src="<?= assets("pages/jquery.dashboard.init.js"); ?>"></script>
        <script src="<?= assets("js/jquery.core.js"); ?>"></script>
        <script src="<?= assets("js/jquery.app.js"); ?>"></script>



        <script type="text/javascript">
        /* ==============================================
             Counter Up
             =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>
</body>
</html>